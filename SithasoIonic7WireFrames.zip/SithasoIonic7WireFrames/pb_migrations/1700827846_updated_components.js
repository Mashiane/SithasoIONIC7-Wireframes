/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zgsu3t0mgv1znn5")

  collection.indexes = [
    "CREATE INDEX `idx_wPJBKcB` ON `components` (`_id`)",
    "CREATE INDEX `idx_9s7sNb2` ON `components` (`parentid`)",
    "CREATE INDEX `idx_bc1Wsb2` ON `components` (`componentactive`)",
    "CREATE INDEX `idx_b8MZzTa` ON `components` (`name`)"
  ]

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zgsu3t0mgv1znn5")

  collection.indexes = [
    "CREATE UNIQUE INDEX `idx_wPJBKcB` ON `components` (`_id`)",
    "CREATE INDEX `idx_9s7sNb2` ON `components` (`parentid`)",
    "CREATE INDEX `idx_bc1Wsb2` ON `components` (`componentactive`)",
    "CREATE UNIQUE INDEX `idx_b8MZzTa` ON `components` (`name`)"
  ]

  return dao.saveCollection(collection)
})
