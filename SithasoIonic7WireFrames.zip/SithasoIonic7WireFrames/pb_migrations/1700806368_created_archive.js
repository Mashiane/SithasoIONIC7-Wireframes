/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const collection = new Collection({
    "id": "9q4bvt6cv39kqwa",
    "created": "2023-11-24 06:12:47.999Z",
    "updated": "2023-11-24 06:12:47.999Z",
    "name": "archive",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "hspcwjbq",
        "name": "componentname",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "vcs7wkhy",
        "name": "content",
        "type": "json",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {}
      },
      {
        "system": false,
        "id": "d0fy5bqi",
        "name": "archivecontent",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      }
    ],
    "indexes": [],
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": "",
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("9q4bvt6cv39kqwa");

  return dao.deleteCollection(collection);
})
