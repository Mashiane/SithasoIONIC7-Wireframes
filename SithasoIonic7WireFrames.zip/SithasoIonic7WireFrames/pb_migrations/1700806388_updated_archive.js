/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("9q4bvt6cv39kqwa")

  // remove
  collection.schema.removeField("vcs7wkhy")

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("9q4bvt6cv39kqwa")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "vcs7wkhy",
    "name": "content",
    "type": "json",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {}
  }))

  return dao.saveCollection(collection)
})
