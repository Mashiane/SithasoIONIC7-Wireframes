/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("9q4bvt6cv39kqwa")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "d0fy5bqi",
    "name": "content",
    "type": "text",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("9q4bvt6cv39kqwa")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "d0fy5bqi",
    "name": "archivecontent",
    "type": "text",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
})
